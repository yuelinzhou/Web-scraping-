variable names - readable version - data type - format - exmaple - units - different categories - description
Serial_Num - Serial Number - character - YYYYJJJHTTNNN - 1970138N12281 - date - (2010JJJHTTNNN-2015JJJHTTNNN) - storm data and status
Season - Year - Intger - 20xx - 2015 - Year - (2010-2015) - year of the storm
Num - Number - character - xx - 01 - # - (01,02...30) - number for the storm
Basin - Basin - factor - xx - EP - BB - (EP,NA....WP) - Basin of the storm
Sub_Basin - sub basin - character - xx - AS - BB- (AS,BB...WA) - sub basin of the storm
Name - name - character - xxxx - BLAS - N/A - (ADRIAN....WIPHA) - name of the storm
ISO_time - time - character - YYYY-MM-DD HH:MM:SS - 2010-05-28 18:00:00 - time - (2010-MM-DD HH:MM:SS - 2015-MM-DD HH:MM:SS) - time of the storm occurs
Nature - nature - character - xx - DS - N/A - (DS....TS) - nature of the storm
Latitude - latitiude - real - (xx.x or xx) - 23.9 - degree - (-61.3 ~ 69) - latitude of the storm
Longitude - longitude - real - (xxx.x or xxx) - 180 - degree - (-179.9 ~ 180) - longitude of the storm
Wind_WMO - wind speed - real - (x or xx) - 40 - knots - (3 ~ 185) - wind speed of the storm
Pres_WMO - air pressure - real - (xxx or xxxx) - 872 - millibars - (872 ~ 1017) - air pressure of the strom