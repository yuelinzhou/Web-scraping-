Variable names | readable version | data type | format | exmaple | different categories | description

paperName | title | character | "xxxx"| "Development on future" | N/A(too much) | paper titles by written this auhtor

researcher | co-author | character | "xxxx" | "A Deaton, J Muellbauer" | N/A(too much) | some contributers and work together to compelete this article

journal | palce | character | "xxxx" | "Cambridge university press, 1980" | N/A(too much) | name of the place

citations | reference of the this article | real | xx | 90 | (0~7400(approximately)) | number citations they use to complete this article

years | time | real | xxxx | 1980 | (1970s ~ 2018) | in certian years they have completed the article
