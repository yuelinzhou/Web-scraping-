# Stat 133, Fall 2019

Private Repository for Workout assignments

- Name: Yuelin Zhou
- Github username: yuelinzhou-git
- Email: yuelinzhou@berkeley.edu
- Lab section: 101
- GSI: Cindy Zhang

-----

## Assignments

- [Demo](demo)
- [Workout 1](workout1)
- [Workout 2](workout2) 
- [Workout 3](workout3)


